import serial
import serial.tools.list_ports
import sys
import time
from datetime import datetime


def append_report(fname, str):
    with open(fname, "a") as file_object:
        file_object.write(str + '\n')


class EightMsMotorController(object):
    def __init__(self, port_number=0, baud_rate=9600, verbose=True):
        if port_number == 0:
            self.ser = self.select_port(baud_rate)
        else:
            self.ser = serial.Serial("COM" + str(port_number), baud_rate, timeout=2)
        if not self.ser.is_open:
            print("Unable to open com port")

        # maximum fixed position of the motor
        self.mxfp = -1

    def __del__(self):
        if self.ser and self.ser.is_open:
            self.ser.close()

    def select_port(self, baud_rate):
        """
        Testtext
        :param baud_rate: Testparameter
        :return:
        """
        comlist = serial.tools.list_ports.comports()
        # comlist.reverse()
        for element in comlist:
            port = element.device
            if port == "COM11":
                break
            print("Try port: " + str(port))
            test = serial.Serial(port, baud_rate, timeout=2)
            test.reset_input_buffer()
            query = bytearray([0x12, 0xC0])
            test.write(query)
            if len(test.read(18)) > 0:
                return test
        raise SystemExit('error in code want to exit')

    def move_to_pos(self, addr, pos, ypos=0):
        data = bytearray([addr, 0]) + int(pos).to_bytes(4, byteorder='little')
        if (ypos == False) and (self.verbose):
            print("Sending move command in X/Y dir")
        self.ser.write(data)

    def motor_status(self, addr):
        self.ser.reset_input_buffer()
        query = bytearray([addr, 0xC1])
        self.ser.write(query)
        status = self.ser.read(9)
        # 0: flag, 1-4: current step_pos, 5-8: target step_pos
        return status

    def analyse_status_flag(self, status):
        flag = ''.join(format(byte, '08b') for byte in status[:1])
        dict = {}
        dict["enbl"] = flag[0]  # enabled
        dict["busy"] = flag[1]  # busy
        dict["ref"] = flag[2]  # referenced
        dict["err"] = flag[3]  # error
        dict["nr"] = flag[4]  # no referencing when starting motor
        dict["SWp"] = flag[6]  # Fixed pos +
        dict["SWm"] = flag[7]  # Fixed pos -
        return dict

    def motor_moving(self, status):
        return analyse_status_flag(status)['busy']

    def reachedPos(self, status):
        actp = int.from_bytes(status[1:4], byteorder='little')
        targ = int.from_bytes(status[5:8], byteorder='little')
        return (actp == targ)

    def current_pos(self, addr):
        status = self.motor_status(addr)
        actp = int.from_bytes(status[1:4], byteorder='little')
        return actp

    def set_motor_speed(addr, vstp):  # vstp == v_step
        query = bytearray([addr, 0xC6]) + vstp.to_bytes(4, byteorder='little')
        self.ser.write(query)

    # def get_motor_speed(addr):
    #    query = bytearray([addr, 0xC6, 0 , 0, 0xC1, 0xFF])
    #    self.ser.write(query)
    #    return int(self.ser.read(4))

    def motor_config(self, addr):
        self.ser.reset_input_buffer()
        query = bytearray([addr, 0xC0])  # address C0
        self.ser.write(query)

        # Only works if communication with one motor only
        if self.mxfp == -1:
            self.mxfp = self.ser.read(10)[0]
            self.ser.read((self.mxfp + 1) * 4)  # clear output buffer
            self.ser.write(query)
        # The response length depends on the configuration of the motor
        # Bytes = mxfp*4 + 14 with mxfp in range -1 (no pos defined) to 15 (fp0...fp15)
        configuration = self.ser.read(self.mxfp * 4 + 14)  # 15 * 4 + 14
        return configuration

    def motor_fixed_positions(self, config):
        max_step_pos = []
        for i in range(self.mxfp + 1):
            max_step_pos.append(int.from_bytes(config[4 * i + 1:4 * (i + 1)], byteorder='little'))

        return max_step_pos

    # def type(self, config):
    #   type_ = str(config[14:17]) #8MS
    #   return type_

    def move_dir_Z(self, addr, mxst):  # implement smaller steps#
        print("Scan in Z dir")
        steps = 100
        for r in range(1, steps + 1):
            self.move_to_pos(addr, mxst * (1 - r / steps), 1)
            while not self.check_atFinalPos(self.motor_status(addr)):
                time.sleep(0.01)
        self.move_to_pos(addr, mxst, 1)
        while not self.check_atFinalPos(self.motor_status(addr)):
            time.sleep(0.01)

    def init_moveTo_pattern_1(self, addrs, fname):
        configs = [self.motor_config(addr) for addr in addrs]
        mxst = [self.motor_mxst(conf) for conf in configs]

        init_pos_X = mxst[0] / 4.
        init_pos_Y = mxst[1] / 4.
        init_pos_Z = mxst[2]

        now = datetime.now()
        report_str = now.strftime("%H:%M:%S") + " | Moving to initial position:" + "({},{},{})".format(int(init_pos_X),
                                                                                                       int(init_pos_Y),
                                                                                                       int(init_pos_Z))
        append_report(fname, report_str)
        print(report_str)

        data = []
        data.append(bytearray([addrs[0], 0]) + int(init_pos_X).to_bytes(4, byteorder='little'))
        data.append(bytearray([addrs[1], 0]) + int(init_pos_Y).to_bytes(4, byteorder='little'))
        data.append(bytearray([addrs[2], 0]) + int(init_pos_Z).to_bytes(4, byteorder='little'))

        for d in range(len(data)):
            self.ser.write(data[d])
            while not self.check_atFinalPos(self.motor_status(addrs[d])):
                time.sleep(1.0)


def main():
    controller = EightMsMotorController(port_number=6)  # Com port hier aendern
    controller.move_to_pos(101, 115, ypos=0)
    controller.move_to_pos(101, 100)

if __name__ == "__main__":
    sys.exit(main())




