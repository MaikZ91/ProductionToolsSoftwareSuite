import ie_Framework.Hardware.Motor.EightMs
from ie_Framework.Hardware.Motor.EightMs import EightMs


class Blaze():

    def __init__(self):
        pass

    @staticmethod
    def getRightMotor(self):
        return EightMs()