from commonIE.PCANBasic import *
import struct

tcpIpPort = 10538


def printMsg(msg):
    if msg is None:
        print("None-Message")
    else:
        print("ID=0x%03x Data=0x" % msg.ID),
        for i in range(msg.LEN):
            print("%02x" % msg.DATA[i]),
        print


def packMsg(msg):
    data = struct.pack("IBBBBBBBBBB", msg.ID, msg.LEN, msg.MSGTYPE, \
                       msg.DATA[0], msg.DATA[1], msg.DATA[2], msg.DATA[3], \
                       msg.DATA[4], msg.DATA[5], msg.DATA[6], msg.DATA[7])
    return data


def unpackMsg(data):
    msg = TPCANMsg()
    (msg.ID, msg.LEN, msg.MSGTYPE, \
     msg.DATA[0], msg.DATA[1], msg.DATA[2], msg.DATA[3], \
     msg.DATA[4], msg.DATA[5], msg.DATA[6], msg.DATA[7]) \
        = struct.unpack("IBBBBBBBBBB", data)
    return msg


def makeMsg(id, dataByteList, length=None):
    msg = TPCANMsg()
    msg.ID = id
    if length:
        msg.LEN = len
    else:
        msg.LEN = len(dataByteList)
    if msg.LEN > 8: msg.LEN = 8
    for i in range(msg.LEN):
        msg.DATA[i] = dataByteList[i]
    return msg


CanBufferSize = 5  # max 5 messages

STATUS_NotInit = 1
STATUS_Prepared = 2
STATUS_Active = 4
STATUS_Error = 8
STATUS_Warning = 16
STATUS_Detected = 64
STATUS_Data = 128
