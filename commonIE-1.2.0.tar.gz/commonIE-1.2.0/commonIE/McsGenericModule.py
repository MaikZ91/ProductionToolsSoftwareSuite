from commonIE.mcsIE import Mcs


class McsGenericModule(object):

    def __init__(self, mcs: Mcs, canID: int):
        self.mcs = mcs
        self.canID = canID

    def isConnected(self, timeout: int = 300, hotplug: bool = False):
        return self.mcs.isConnected(self.canID, timeout=timeout, hotplug=hotplug)

    def resetAndInit(self):
        self.reset()
        self.init()

    def waitReady(self, waitReadyTime: int = 10):
        self.mcs.waitReady(self.canID, waitReadyTime=waitReadyTime)

    def init(self, cmdMode=0, waitReadyTime=10):
        self.mcs.init(self.canID, cmdMode=cmdMode, waitReadyTime=waitReadyTime)

    def reset(self, cmdMode=0xff, waitReadyTime=10):
        self.mcs.reset(self.canID, cmdMode=cmdMode, waitReadyTime=waitReadyTime)

    def operate(self, cmdMode, waitReadyTime=0):
        self.mcs.operate(self.canID, cmdMode, waitReadyTime=waitReadyTime)  # default# different from other commands !!!

    def setTargetValue(self, value):
        self.mcs.setTargetValue(self.canID, value)

    def setTargetValueBDC(self, value):
        self.mcs.setTargetValueBDC(self.canID, value)  # deprecated! only used in TEC5 Firmware.

    # Use setTargetValue instead

    def move(self, cmdMode, position, speed, waitReadyTime=10):
        self.mcs.move(self.canID, cmdMode, position, speed, waitReadyTime=waitReadyTime)

    def moveDiscrete(self, cmdMode, positionID, direction='CCW', waitReadyTime=10):
        self.mcs.moveDiscrete(self.canID, cmdMode, positionID, direction=direction, waitReadyTime=waitReadyTime)

    def getMove(self):
        return self.mcs.getMove(self.canID)

    def setRamping(self, accel, decel):
        self.mcs.setRamping(self.canID, accel, decel)

    def getRamping(self):
        return self.mcs.getRamping(self.canID)

    def setDiscretePosition(self, positionID, position):
        self.mcs.setDiscretePosition(self.canID, positionID, position)

    def getDiscretePosition(self, positionID):
        return self.mcs.getDiscretePosition(self.canID, positionID)

    def stop(self, cmdMode=0):
        self.mcs.stop(self.canID, cmdMode=cmdMode)

    def getPort(self, port, signed=False):
        return self.mcs.getPort(self.canID, port, signed=signed)

    def setPort(self, length, port, value, pulseTime=0):
        self.mcs.setPort(self.canID, length, port, value, pulseTime=pulseTime)

    def setPortMode(self, port, mode, dataValidTime=0, portIdleTime=0):
        self.mcs.setPortMode(self.canID, port, mode, dataValidTime=dataValidTime, portIdleTime=portIdleTime)

    def getPortParameter(self, port, parameter, signed=False):
        return self.mcs.getPortParameter(self.canID, port, parameter, signed=signed)

    def setPortParameter(self, length, port, parameter, value):
        self.mcs.setPortParameter(self.canID, length, port, parameter, value)

    def portZeroSet(self, port, waitReadyTime=5):
        self.mcs.portZeroSet(self.canID, port, waitReadyTime=waitReadyTime)

    def getParameter(self, parameter, signed=False):
        return self.mcs.getParameter(self.canID, parameter, signed=signed)

    def setParameter(self, length, parameter, value):
        self.mcs.setParameter(self.canID, length, parameter, value)

    def getMem(self, length, address, signed=False):
        return self.mcs.getMem(self.canID, length, address, signed=signed)

    def eraseMem(self, address, waitReadyTime=15):
        self.mcs.eraseMem(self.canID, address, waitReadyTime=waitReadyTime)

    def setMem(self, length, address, data):
        self.mcs.setMem(self.canID, length, address, data)  # data is integer, 8..32 bit

    def setMem2(self, length, address, data0, data1, data2, data3):
        self.mcs.setMem2(self.canID, length, address, data0, data1, data2, data3)  # data0...data3 are 8bit integers

    def setMemArray(self, length, address, data):
        self.mcs.setMemArray(self.canID, length, address, data)  # data is array of characters (ord(data[i]) is sent)

    def getMemArray(self, length, address):
        return self.mcs.getMemArray(self.canID, length, address)  # returns array of 8 bit values from telegram

    def getMemString(self, length, address):
        return self.mcs.getMemString(self.canID, length, address)

    def setAuxData(self, length, data):
        self.mcs.setAuxData(self.canID, length, data)

    def getAuxData(self, length=0x08):
        return self.mcs.getAuxData(self.canID, length=length)

    def getError(self):
        return self.mcs.getError(self.canID)  # info1 (queried from module, not cached)

    def getVersion(self, versionType: int = 0):
        return self.mcs.getVersion(self.canID, versionType=versionType)  # info3

    def getHardwareVersion(self):
        return self.mcs.getHardwareVersion(self.canID)  # info5

    def getCommunicationError(self):
        return self.mcs.getCommunicationError(self.canID)  # info6

    def getStatus(self):
        return self.mcs.getStatus(self.canID)

    def isBusy(self):
        return self.mcs.isBusy(self.canID)

    def isPrepared(self):
        return self.mcs.isPrepared(self.canID)

    def isNotInitialized(self):
        return self.mcs.isNotInitialized(self.canID)

    def isInitialized(self):
        return self.mcs.isInitialized(self.canID)

    def isIdle(self):
        return self.mcs.isIdle(self.canID)

    def hasError(self):
        return self.mcs.hasError(self.canID)

    def hasWarning(self):
        return self.mcs.hasWarning(self.canID)

    def hasData(self):
        return self.mcs.hasData(self.canID)

    def hasDetected(self):
        return self.mcs.hasDetected(self.canID)

    def setThrowError(self, setting=True):
        self.mcs.setThrowError(self.canID, setting=setting)

    def setThrowBufferOverflow(self, setting=True):
        self.mcs.setThrowBufferOverflow(self.canID, setting=setting)
