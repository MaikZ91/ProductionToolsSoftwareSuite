import enum
from abc import abstractmethod, ABCMeta, ABC
from datetime import datetime


class mBarcodeType(enum.Enum):
    virtual=-10
    unset = -2
    invalid = -1
    unknown = 0
    version1 = 1
    version2 = 2
    rollingNumber =10


class virtualBarcode(metaclass=ABCMeta):

    def __init__(self,barcodeText:str):
        self.__Text = barcodeText
        self.barcodeType = mBarcodeType.virtual


    def getBarcodeText(self):
        return self.__Text

    @abstractmethod
    def inputBarcode(self,barcode:str):
        pass

    # Version1: 99991120020579251502111413000040
    # Version2: 010404993400377610624040002117251030210000400091200070501007105
    @staticmethod
    def returnBarcodeType(barcodeText: str):
        lenText = len(barcodeText)
        if lenText >= 31:
            if barcodeText[:5] == "99991":  # This can be edited in the future as new versions appear
                return mBarcodeType.version1
            elif barcodeText[0:1] == "01" and lenText > 60:
                return mBarcodeType.version2
            else:
                return mBarcodeType.unknown
        else:
            if lenText == 0:
                return mBarcodeType.unset
            else:
                return mBarcodeType.invalid



class mBarcode(virtualBarcode):

    def __init__(self, barcodeText: str):
        super().__init__(barcodeText)
        self.__Text = ""
        self.__chargeNumber = ""
        self.__matNumber = ""
        self.__gTin = ""
        self.__counter = ""
        self.__prodDate = ""
        self._valid = False
        self.barcodeType = mBarcodeType.invalid
        self.inputBarcode(barcodeText)


    def inputBarcode(self, barcodeText: str):
        self.barcodeType = self.returnBarcodeType(barcodeText)
        if self.barcodeType != mBarcodeType.invalid and self.barcodeType != mBarcodeType.unset:
            self.__Text = barcodeText
            if self.barcodeType == mBarcodeType.version1:
                self.__matNumber = barcodeText[5: 14]
                self.__chargeNumber = barcodeText[15: 25]
                self.__counter = barcodeText[26:31]
                self._valid = True
            else:
                self.__gTin = barcodeText[2:15]
                self.__chargeNumber = barcodeText[18:27]
                self.__prodDate = barcodeText[30:35]
                self.__counter = barcodeText[38:42]
                self.__matNumber = barcodeText[45:]


    def getBarcodeType(self):
        return self.barcodeType

    def getValid(self) -> bool:
        return self._valid

    def getMatNumber(self) -> str:
        return self.__matNumber

    def getCharge(self) -> str:
        return self.__chargeNumber

    def getGTin(self) -> str:
        return self.__gTin

    def getNumber(self) -> str:
        return self.__counter

    def getProdDate(self) -> str:
        return self.__prodDate

class numberBarcode(virtualBarcode):

    def __init__(self, barcode:str,testDate:datetime):
        super().__init__()
        self.__year = testDate.year
        self.__Text = "%s_%d" %(barcode,testDate.year)
        self.barcodeType = mBarcodeType.rollingNumber

    def getBarcodeText(self):
        return self.__Text

    def inputBarcode(self,barcode:str):
        self.__Text ="%s_%d" %( barcode,self.__year)


