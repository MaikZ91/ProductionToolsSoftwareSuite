import logging
import socket
import time
from datetime import datetime
from io import StringIO
import socks
from  commonIE import miltenyiBarcode
import pandas

SQLDATETIMEFORMAT = "%Y-%m-%d_%H:%M:%S"
SQLDATEFORMAT = "%y-%m-%d"
SQLTIMEFORMAT = "%H:%M:%S"

class connection():

    _instance = None

    def __init__(self):
        self.host = "MDEBGLPRDSPCP01"
        self.port = 50001
        self.valid=True
        self.connected = False
        self.database = ""
        self.dbPort = 0
        self.comm_socket = None
        self.testEquipt = None
        self.debugging = False
        self.__throwErrors = True

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()


    def connect(self) ->int:
        try:
            client_socket = socks.socksocket()
            client_socket.setblocking(True)
            client_socket.settimeout(2)
            client_socket.connect((self.host, self.port))  # connect to the server

            # message = input(" -> ")  # take input
            connectInfo = client_socket.recv(4096).decode("utf-8")
            infos = connectInfo.split(";")
            if len(infos) < 2:
                self.valid = False
                self.connected = False
                logging.warning("No valid connect answer from %s." %self.host)
                return -2
            else:
                # $send start=24-01-01_19:00:00 end=24-01-01_20:00:00 result=0 test=Dummy;
                self.comm_socket = client_socket
                self.connected = True
                return 0
        except socket.timeout as e:
            logging.warning("Unable to connect to %s. Service is down or not in miltenyi network." % self.host)
            if self.__throwErrors:
                raise Exception("Unable to connect to %s. Service is down or not in miltenyi network." % self.host)
            return -1


    def disconnect(self):
        if self.connected:
            self.comm_socket.close()
            self.connected = False
            self.comm_socket = None
            self.dbPort = 0
            self.database = ""

    def sendData(self,start:datetime,end:datetime,result:int,testName:str,testValues: dict,
                 deviceBarcode: miltenyiBarcode.virtualBarcode = None,worker_shortname:str = "") -> int:
        if not self.connected or not self.valid: # Only available when connected and connection is valid.
            return -1
        else:
            payload = "$send start=%s end=%s result=%d test=%s" % (start.strftime(SQLDATETIMEFORMAT),end.strftime(SQLDATETIMEFORMAT),result,testName)
            if deviceBarcode is not None:
                payload = payload + " device=%s" % deviceBarcode.getBarcodeText()
            if worker_shortname != "":
                payload = payload + " user=%s" % worker_shortname
            if self.testEquipt is not None:
                payload = payload + " testequip=%s" % self.testEquipt
            header = str(list(testValues.keys()))[1:-1].replace("'","").replace(" ","")
            payload = payload + ";"
            payload2 = "%s;" % header
            if type(testValues[list(testValues.keys())[0]]) == list:
                for i in range(len(testValues[list(testValues.keys())[0]])):
                    line = ""
                    for key in testValues.keys():
                            line = line + "%s," %testValues[key][i]
                    payload2 = payload2 + "%s;" % line[:-1]
            else:
                line = ""
                for key in testValues.keys():
                    line = line + "%s," % testValues[key]
                payload2 = payload2 + "%s;" % line[:-1]
            payload2 = payload2 + "$$$;"
            if self.debugging:
                print(payload)
                print(payload2)
                return 0
            else:
                start = time.time()
                self.comm_socket.send(payload.encode("utf-8"))
                if  self._readTaskResponse()[0] == 0:
                    time1 = time.time()
                    self.comm_socket.send(payload2.encode("utf-8"))
                result = self._readTaskResponse()[0]
                print("Time1 = %f and time2 = %f" %(time1-start,time.time()-time1))
                return result
            #TODO check if ok and return accordingly


    def sendDataNoBarcode(self,start:datetime,end:datetime,result:int,testName:str,testValues: dict,
                 deviceBarcode: str,worker_shortname:str = "") -> int:
        '''
        This method is used to send data for devices that do not use regular Barcodes. Important is to create a unique
        sequence to identify the device for
        :param start: Start of the Test
        :param end: End of the Test
        :param result: The Result as a integer for the specific Test
        :param testName: The Name of the Test
        :param testValues: A dictonairy for the specific values.
        :param deviceBarcode: The Barcode or in this case the Name of the Device that has been tested
        :param worker_shortname: The shortname of the worker that tested the Device
        :return: Returns an int that indicates wheter or not the sending succeded.
        '''
        if not self.connected or not self.valid: # Only available when connected and connection is valid.
            return -1
        else:
            payload = "$send start=%s end=%s result=%d test=%s" % (start.strftime(SQLDATETIMEFORMAT),end.strftime(SQLDATETIMEFORMAT),result,testName)
            if deviceBarcode is not None:
                payload = payload + " device=%s" % deviceBarcode
            if worker_shortname != "":
                payload = payload + " user=%s" % worker_shortname
            if self.testEquipt is not None:
                payload = payload + " testequip=%s" % self.testEquipt
            header = str(list(testValues.keys()))[1:-1].replace("'","").replace(" ","")
            payload = payload + ";"
            payload2 = "%s;" % header
            if type(testValues[list(testValues.keys())[0]]) == list:
                for i in range(len(testValues[list(testValues.keys())[0]])):
                    line = ""
                    for key in testValues.keys():
                            line = line + "%s," %testValues[key][i]
                    payload2 = payload2 + "%s;" % line[:-1]
            else:
                line = ""
                for key in testValues.keys():
                    line = line + "%s," % testValues[key]
                payload2 = payload2 + "%s;" % line[:-1]
            payload2 = payload2 + "$$$;"
            if self.debugging:
                print(payload)
                print(payload2)
                return 0
            else:
                start = time.time()
                self.comm_socket.send(payload.encode("utf-8"))
                if self._readTaskResponse()[0] == 0:
                    time1 = time.time()
                    self.comm_socket.send(payload2.encode("utf-8"))
                    result = self._readTaskResponse()[0]
                    print("Time1 = %f and time2 = %f" %(time1-start,time.time()-time1))
                    return result
                else:
                    logging.warning("Service unable to receive send request" % self.host)
                    if self.__throwErrors:
                        raise Exception("Unable to send data to service")
            #TODO check if ok and return accordingly

    def getTestInTime(self,start:datetime,stop:datetime,testtypeName:str = "",data: bool = False):
        if not self.connected or not self.valid:
            return -1
        else:
            payload = "$tests from=%s to=%s" %( start.strftime(SQLDATETIMEFORMAT),stop.strftime(SQLDATETIMEFORMAT))
            if testtypeName != "":
                payload = payload + " testName=%s" % testtypeName
            if data:
                payload = payload + " data=1"
            payload = payload + ";"
            print(payload)
            self.comm_socket.send(payload.encode("utf-8"))
            #TODO check response and return it later?
            result, data = self._readDataResonse()
            if result == 0:
                return data
            else:
                return result

    def getEventsInTime(self,start:datetime,stop:datetime):
        if not self.connected or not self.valid:
            return -1
        else:
            payload = "$eventsintime from=%s to=%s" %( start.strftime(SQLDATETIMEFORMAT),stop.strftime(SQLDATETIMEFORMAT))

            payload = payload + ";"
            print(payload)
            self.comm_socket.send(payload.encode("utf-8"))
            #TODO check response and return it later?
            result, data = self._readDataResonse()
            if result == 0:
                return data
            else:
                return result

    def getTesttypes(self):
        payload= "$Testtypes;"
        self.comm_socket.send(payload.encode("utf-8"))
        result, data = self._readDataResonse()
        if result != 0:
            self.disconnect()
            self.valid = False
            return "Error"
        else:
            return data

    def getLastTests(self, count: int, testName: str):
        payload = "$LastTests count=%d testName=%s;" % (count, testName)
        self.comm_socket.send(payload.encode("utf-8"))
        result, data = self._readDataResonse()
        if result != 0:
            self.disconnect()
            self.valid = False
            return "Error"
        else:
            return data

    def _readTaskResponse(self):
        data=""
        while ";" not in data:
            data = data + self.comm_socket.recv(4096).decode("utf-8")  # receive response
        if "Error" in data:
            return -1, data
        elif "NACK" in data:
            return -2, data
        elif "ack":
            return 0, data
        else:
            return 1, data # Unknown return. Check will be done in underlying function

    def _readDataResonse(self):
        data = ""
        while ";" not in data:
            data = data + self.comm_socket.recv(4096).decode("utf-8")  # receive response
        if "Error" in data:
            return -1, data
        else:
            pos = data.find(":")
            data = data[pos+1:]
            data = pandas.read_csv(StringIO(data), sep=",")
            return 0, data

    def getTestData(self,test_GUID:str):
        payload = "$data id=%s;" %test_GUID
        self.comm_socket.send(payload.encode("utf-8"))
        result, data = self._readDataResonse()
        if result == 0:
            return data
        else:
            return "Error"

    def getTestPara(self,testName:str):
        payload = "$para test=%s;" %testName
        self.comm_socket.send(payload.encode("utf-8"))
        result, data = self._readTaskResponse()
        return data

    def announceDeviceWithName(self,maindevice,subdevice,foundDate:datetime=datetime.now(),slot:str=None):
        payload = "$devicefound device=%s in=%s date=%s" %(subdevice,maindevice,foundDate.strftime(SQLDATETIMEFORMAT))
        if slot is not None:
            payload  = payload + " slot=%s" %slot
        payload=payload+";"
        self.comm_socket.send(payload.encode("utf-8"))
        result, data = self._readTaskResponse()
        return result

    def getMaindevices(self,devices: list):
        deviceList = ','.join(devices)
        payload = "$devicegroup deviceList=%s;" %deviceList
        self.comm_socket.send(payload.encode("utf-8"))
        result, data = self._readDataResonse()
        return data

    #def announceDeviceWithGUID(self, maindevice, subdevice, foundDate: datetime = datetime.now(), slot: str = None):
    #    payload = "$devicefound device=%s in=%s date=%s" % (
    #    subdevice, maindevice, foundDate.strftime(SQLDATETIMEFORMAT))
    #    if slot is not None:
    #        payload = payload + " slot=%s" % slot
    #    payload = payload + ";"
    #    self.comm_socket.send(payload.encode("utf-8"))
    #    result, data = self._readDataResonse()


