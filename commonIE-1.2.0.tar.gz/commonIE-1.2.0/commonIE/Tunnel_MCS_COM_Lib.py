# print-Function Python 3 -> Python 2 compatible.
from __future__ import print_function
import time


class TunnelMcsCom:

    def __init__(self, mcs, mcsID):
        self.mcsID = mcsID
        self.mcs = mcs

    # Set- / Get-Mem functionality.
    def write(self, cmd):
        print("Set Mem () + Operate()")
        # Create UART command
        cmdLength = len(cmd)
        numberOf8ByteMsg = cmdLength // 4
        rest = cmdLength % 4
        print(cmd, cmdLength, numberOf8ByteMsg, rest, sep=", ")

        a = 0
        for i in range(numberOf8ByteMsg):
            print(cmd[a:a + 4])
            self.mcs.setMemArray(self.mcsID, length=4, address=a, data=cmd[a:a + 4])  # send cmd as list
            a += 4
        if rest:
            print(cmd[a:a + rest])
            self.mcs.setMemArray(self.mcsID, length=rest, address=a, data=cmd[a:a + rest])  # send cmd as list
        # Send character string via UART
        self.mcs.operate(self.mcsID, cmdMode=1, waitReadyTime=0)  # firmware needs short busy state to query answer

    def readArray(self, recdCnt):
        print("Get Mem ()")
        print(recdCnt)
        # Calculate number of 8byte MCS-Mem-Data() messages
        numberOf8ByteMsg = recdCnt // 7
        # Calculate length of last MCS-Mem-Data() message
        rest = recdCnt % 7
        print(recdCnt, numberOf8ByteMsg, rest, sep=", ")
        # Clear data holder
        answer = []
        a = 0
        for i in range(numberOf8ByteMsg):
            answer.extend(self.mcs.getMemArray(self.mcsID, length=7, address=a))  # read memory data as list
            a += 7
        if rest:
            answer.extend(self.mcs.getMemArray(self.mcsID, length=rest, address=a))  # read memory data as list

        print(answer)
        return answer

    def readString(self, recdCnt):
        print("Get Mem ()")
        print(recdCnt)
        # Calculate number of 8byte MCS-Mem-Data() messages
        numberOf8ByteMsg = recdCnt // 7
        # Calculate length of last MCS-Mem-Data() message
        rest = recdCnt % 7
        print(recdCnt, numberOf8ByteMsg, rest, sep=", ")
        # Clear data holder
        answer = ""
        a = 0
        for i in range(numberOf8ByteMsg):
            answer += self.mcs.getMemString(self.mcsID, length=7, address=a)  # read memory data as string
            a += 7
        if rest:
            answer += self.mcs.getMemString(self.mcsID, length=rest, address=a)  # read memory data as string
        print(answer)
        return answer

    def readBuffer(self, bufferIdx, byteCnt):
        print("Get Mem ()")
        print(bufferIdx)
        # Calculate number of 8byte MCS-Mem-Data() messages
        numberOf8ByteMsg = byteCnt // 7
        # Calculate length of last MCS-Mem-Data() message
        rest = byteCnt % 7
        print(byteCnt, numberOf8ByteMsg, rest, sep=", ")
        # Clear data holder
        answer = ""
        for i in range(numberOf8ByteMsg):
            answer += self.mcs.getMemString(self.mcsID, length=7, address=bufferIdx)  # read memory data as string
            bufferIdx += 7
        if rest:
            answer += self.mcs.getMemString(self.mcsID, length=rest, address=bufferIdx)  # read memory data as string
        print(answer)
        return answer
