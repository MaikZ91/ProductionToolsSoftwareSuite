#-------------------------------------------------------------------------------
# Name:        MCS_irregularEvent
# Purpose:
#
# Author:      runem
#
# Created:     04.08.2020
# Copyright:   (c) runem 2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------

# Source:
# https://docs.python.org/3/howto/logging-cookbook.html#network-logging

import logging.handlers
import time
import logging
import os
import csv
from PySide6 import QtWidgets, QtCore
import sys
import subprocess
import pickle
import threading

# Expand logging module with "event" level (between warn and error level)
levelName = "IRREVENT"
DEBUG_LEVELV_NUM = 35
def event(self, message, *args, **kws):
    # Yes, logger takes its '*args' as 'args'.
    if self.isEnabledFor(DEBUG_LEVELV_NUM):
        message = self.irregularEvent.format( message )
        self._log(DEBUG_LEVELV_NUM, message, args, **kws)
        self.irregularEvent.ieCounter += 1
logging.addLevelName(DEBUG_LEVELV_NUM, levelName)
logging.Logger.event = event

# =============================================================================
class IrregularEvent(object):
# =============================================================================
    def __init__(self, useGUI=True):
        self.moduleEventNames, self.moduleEventTexts = self.getModuleEvents()
        self.moduleNames = self.getModuleNames()

        # Create Logger
        self.logger = logging.getLogger(levelName)
        self.logger.setLevel(logging.DEBUG)

        # add the instance of this class to logger, so the event function can
        # use it
        self.logger.irregularEvent = self

        self.guiProcess = None
        self.channel = None
        self.thread = None
        if useGUI:
            self.gui_start()

        self.ieCounter = 0
        self.status = 'running'

    def format(self, msg,):
        canID = msg.DATA[1] << 8 | msg.DATA[0]
        eventID = msg.DATA[3] << 8 | msg.DATA[2]

        if eventID == 0xffff:
            message = "\t \t \t \t \t \t <event buffer overflow>"
            return message

        try:
            explanation = self.moduleEventTexts[canID&0xff][eventID]
        except KeyError:
            explanation = ""
        except:
            raise

        try:
            eventName = "[" + self.moduleEventNames[canID&0xff][eventID] + "] "
        except KeyError:
            eventName = "[] "
        except:
            raise
        moduleName = "[" + self.moduleNames[canID&0xff] + "]"

        if explanation.find("IRREGULAR_EVENT_VALUE") >= 0:
            shift=0
            value=0
            for i in range(4,msg.LEN):
                value = value | (msg.DATA[i]<<shift)
                shift = shift+8
            IRREGULAR_EVENT_VALUE = value
            try:
                evalExplanation = eval(explanation)
            except Exception as err:
                evalExplanation = err
                print(err)
            message="0x%03X\t0x%04X\t0x%02X\t0x%02X\t0x%02X\t0x%02X\t%s" %(canID, \
                    eventID,  msg.DATA[4], msg.DATA[5], msg.DATA[6], \
                    msg.DATA[7], moduleName+eventName+evalExplanation)
        else:
            message="0x%03X\t0x%04X\t0x%02X\t0x%02X\t0x%02X\t0x%02X\t%s" \
                    %(canID, eventID,  msg.DATA[4], msg.DATA[5], msg.DATA[6], \
                    msg.DATA[7], moduleName+eventName+explanation)

        return message

    def getModuleEvents(self):
        '''
        returns moduleEventNames, moduleEventTexts as two dimensional dictonary

        Always access getModuleEventText like this:
            try:
                name = moduleEventNames[canID][eventID]
            except KeyError:
                name = ''
            except:
                raise
            try:
                text = moduleEventTexts[canID][eventID]
            except KeyError:
                text = ''
            except:
                raise
        '''

        moduleEventNames = {}
        moduleEventTexts = {}

        csvfile= open(os.path.dirname(os.path.abspath(__file__))+os.sep+'MCS_irregularEventCodes.csv','rb')
        reader = csv.reader(csvfile, delimiter=';')

        for row in reader:
            if ("#" in row[0]) or (row[0].strip()=="") or ('sep=' in row[0]) or row==[]:
                #skip comment or blank lines
                continue

            if row[0] == "" or row[1] == "":
                # dont save information
                continue

            canID = int(row[0], 16) & 0xff
            eventID = int(row[1], 16) & 0xff
            name = row[2]
            text = row[3]

            try:
                moduleEventNames[canID]
            except KeyError:
                moduleEventNames[canID] = {}
            try:
                moduleEventTexts[canID]
            except KeyError:
                moduleEventTexts[canID] = {}

            moduleEventNames[canID][eventID] = name
            moduleEventTexts[canID][eventID] = text

        return moduleEventNames, moduleEventTexts

    def getModuleNames(self):
        '''
        returns moduleNames as one dimensional list[string]

        # getting a module name:
        myStringName = moduleNames[0x491 & 0xff]
        '''

        moduleNames = []
        for canID in range(0x0, 0x100):
            moduleNames.append('')

        csvfile= open(os.path.dirname(os.path.abspath(__file__))+os.sep+'MCS_ModuleNames.csv','rb')
        reader = csv.reader(csvfile, delimiter=';')

        for row in reader:
            if ("#" in row[0]) or (row[0].strip()=="") or ('sep=' in row[0]) or row==[]:
                #skip comment or blank lines
                continue

            if row[0] == "" or row[1] == "":
                # leave it empty -> []
                continue

            canID = int(row[0], 16) & 0xff
            text = row[1]

            moduleNames[canID] = text

        return moduleNames

    def close(self):
        self.status = 'closed'
        if isinstance(self.channel, MessageChannel):
            self.channel.send(self.status)
        for handler in self.logger.handlers:
            handler.close()
        # wait for closing the process
        if isinstance(self.guiProcess, subprocess.Popen):
            self.guiProcess.wait()

    def gui_start(self):
        # path to MCS_PYTHON_SIMPLE
        ps = commonpath.ps[:commonpath.ps.find('TestScripts')]
        if os.name=="nt":
            p1=ps+"App"+os.sep+"python.exe"
        else:
             raise ValueError("operating system not yet supported")

        p2=ps+"TestScripts"+os.sep+"_common"+os.sep+"MCS_IrregularEvent.py"

        if not os.path.isfile(p1):
            print("Start Irregular Event GUI Error: file "+p1+" not found")
        elif not os.path.isfile(p2):
            print("Start Irregular Event GUI Error: file "+p2+" not found")

        self.guiProcess = subprocess.Popen([p1,p2],shell=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE, bufsize=-1,stderr=None,creationflags=subprocess.CREATE_NEW_CONSOLE)
        self.channel = MessageChannel(self.guiProcess.stdin, self.guiProcess.stdout)
        self.thread = threading.Thread(target=self.gui_runner)
        self.thread.setDaemon(True)
        self.thread.start()
        print('irregular event gui started')

    def gui_runner(self):

        while(True):
            # Update GUI every half second
            time.sleep(0.5)

            try:
                self.channel.send(self.ieCounter)
            except:
                if self.guiProcess.poll() is not None:
                    break

            try:
                self.channel.send(self.status)
            except:
                if self.guiProcess.poll() is not None:
                    break

class IrregularEventCSV(IrregularEvent):

    def __init__(self):

        super(IrregularEventCSV, self).__init__()

        try:
            self.addFileHandler()
        except:
            # Raise error and also show this in GUI
            self.status = 'ERROR: Could not open CSV-File because it is already open.'
            raise

    def addFileHandler(self):

        ps = commonpath.ps[:commonpath.ps.find('_common')]

        # Add rotating File Stream Handler
        formatter = logging.Formatter("%(asctime)s:%(msecs)03d\t" +
            "%(message)s", "%Y-%m-%d %H:%M:%S")
        preamble = "sep=  \n" + \
                   "#version=1.0\n"
        header = "#time\tcanID\teventID\tdata0\tdata1\tdata2\tdata3\texplanation\n"
        fileHandler = handlersWithHeaders.RotatingFileHandler(
            ps+os.sep+'irregularEventLog.csv',
            preamble, header,
            maxBytes=1000000, backupCount=5)
        fileHandler.setLevel(logging.DEBUG)
        fileHandler.setFormatter(formatter)
        self.logger.addHandler(fileHandler)

# source: https://www.dabeaz.com/usenix2009/concurrent/Concurrent.pdf
class MessageChannel(object):
    def __init__(self, out_f, in_f):
        self.out_f = out_f
        self.in_f = in_f
    def send(self, item):
        pickle.dump(item, self.out_f)
        self.out_f.flush()
    def recv(self):
        return pickle.load(self.in_f)

# =============================================================================
# From here Irregular Event GUI Application
# =============================================================================
class MyWindowClass(QtWidgets.QWidget):

    def __init__(self, parent=None):

        super(MyWindowClass, self).__init__(parent)

        self.setWindowTitle('Irregular Event')
        self.onClose = False

        self.lbl1 = QtGui.QLabel("Status:",self)
        self.lblStatus = QtGui.QLabel("running",self)
        self.lbl2 = QtGui.QLabel("Number of Irregular Events:",self)
        self.lblNumOfIE = QtGui.QLabel("0",self)

        grid = QtGui.QGridLayout()
        grid.setSpacing(10)
        grid.addWidget(self.lbl1,0,0)
        grid.addWidget(self.lbl2,1,0)
        grid.addWidget(self.lblStatus,0,1)
        grid.addWidget(self.lblNumOfIE,1,1)
        self.setLayout(grid)
        self.setGeometry(50, 50, 200, 50)

        self.thread = Worker(self)
        self.thread.setTerminationEnabled(True)
        self.thread.start()
        self.numOfIE = 0

        # Move window
        self.move(self.frameGeometry().x()-10,
                  self.frameGeometry().y()+self.frameGeometry().height() + 20)
        self.show()
        self.display()

    def changeStatus(self, newStatus):
        self.lblStatus.setText(newStatus)
        print('new status: ')
        print('newStatus')

    def display(self):
        self.lblNumOfIE.setText(str(self.numOfIE))
        if self.onClose == False:
            QtCore.QTimer.singleShot(0.5, self.display)

    def closeEvent(self, event):
        print('closed')
        time.sleep(1)
        self.onClose = True
        event.accept()


class Worker(QtCore.QThread):

    def __init__(self, parent):
        super(Worker, self).__init__()
        self.parent = parent

    def run(self):
        """

        """

        ch = MessageChannel(sys.stdout, sys.stdin)

        while(True):

            try:
                inputValue = ch.recv()
            except EOFError:
                print('EOFError')
                time.sleep(1)
                break
            except:
                continue

            if isinstance(inputValue, int):
                # Number of irregular events
                self.parent.numOfIE = inputValue

            elif isinstance(inputValue, str):
                # Status as string
                if inputValue == 'ERROR: Could not open CSV-File because it is already open.':
                    self.parent.changeStatus(inputValue)
                elif inputValue == 'closed':
                    self.parent.close()
                    print('closed')
                    time.sleep(1)
                    break

if __name__ == '__main__':

    app = QtGui.QApplication(sys.argv)
    myWindow = MyWindowClass(None)

    sys.exit(app.exec_())

