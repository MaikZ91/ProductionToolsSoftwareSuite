# This Module handles all communication with the Tecboard ("MCS Board")
# TODO write a manual for this class and make it more usable outside of the full Prodigy

import socket  # Import socket module
import time
import subprocess
from commonIE.MCS_lib import *
import threading
import sys
import os
import traceback
import csv
from commonIE.MCS_irregularEvent import IrregularEvent, IrregularEventCSV
import io


class McsError(Exception):
    def __init__(self, value=0):
        self.value = value

    def __str__(self):
        return repr(self.value)


class McsStoppedByUser(Exception):
    def __init__(self):
        pass

    def __str__(self):
        pass


# =============================================================================
class Reader:
    # =============================================================================

    def __init__(self, modules, mcs):
        self.modules = modules
        self.mcs = mcs
        self.read_running = True
        self.irregularEvent = None
        if self.mcs.useIrregularEventLog:
            if isinstance(self.mcs.commInterface, CommInterfaceCAN):
                # MCS UseServer=False: CSV-Log has to be done in this process
                try:
                    self.irregularEvent = IrregularEventCSV()
                except IOError:
                    print('Could not open CSV-File because it is already open.')
                    self.irregularEvent = None
                except:
                    raise
            elif isinstance(self.mcs.commInterface, CommInterfaceSocket):
                # MCS UseServer=True: CSV-Log will be done in MCS Server
                self.irregularEvent = IrregularEvent(useGUI=False)
        t1 = threading.Thread(target=self.read_msg)
        t1.start()

    def close(self):
        self.read_running = False
        if self.irregularEvent is not None:
            self.irregularEvent.close()
            self.irregularEvent = None

    def read_msg(self):
        while self.read_running:
            msg, errText = self.mcs.commInterface.read_in_loop()
            if self.read_running:
                if errText:
                    self.mcs.setError(0, 0, errText)
                if msg:
                    if msg.ID < 256:  # Get only MCS Modules (Range: 0 to 255)
                        self.modules[msg.ID].putMsg(msg)
                    elif msg.ID == 0x7FE and self.irregularEvent is not None:
                        # Get Irregular Events
                        self.irregularEvent.logger.event(msg)


# =============================================================================
class CanModule(object):
    # =============================================================================

    def __init__(self, mcs, canId):
        self.mcs = mcs  # reference to mcs object
        self.canId = canId
        self.status = 0xff
        self.error = 0
        self.connected = None
        self.buffer = []
        self.throwError = True
        self.throwBufferOverflow = True
        self.newErrorTimer = 0

    def putMsg(self, msg):  # place new received message in module's buffer
        bufferMessage = True  # enqueue this message in buffer
        if msg.DATA[0] == 0x00:  # Info0 -> update status
            if ((self.status & STATUS_Error) == 0) and ((msg.DATA[1] & STATUS_Error) == STATUS_Error):
                self.newErrorTimer = self.mcs.newErrorReportDelay
                # print ("canID 0x{0:02x} Status{1:02x} Timer{2:d}".format(self.id,self.status,self.newErrorTimer))
            if self.status != msg.DATA[1]:
                self.status = msg.DATA[1]  # update status
                # print ("canID 0x{0:02x} Status{1:02x}".format(self.id,self.status))
                if not (self.status & STATUS_Error):  # reset error code
                    self.error = 0
            if msg.DATA[2] == 0x00:  # Info0 that is NOT an acknowledge
                bufferMessage = False
        if bufferMessage:
            if len(self.buffer) >= CanBufferSize:
                self.buffer.pop(0)  # throw away oldest message
                if self.throwBufferOverflow:
                    self.mcs.setError(0, self.canId, "CAN receive buffer overflow")
            self.buffer.append(msg)

    def getMsg(self):
        if len(self.buffer) > 0:
            return self.buffer.pop(0)
        else:
            return None

    def getMsgAvailable(self):
        return len(self.buffer)

    def getStatus(self):
        return self.status

    def getError(self):
        return self.error

    def setThrowError(self, setting=True):
        self.throwError = setting

    def getThrowError(self):
        return self.throwError

    def setThrowBufferOverflow(self, setting=True):
        self.throwBufferOverflow = setting


# =============================================================================
class CommInterfaceCAN:
    # =============================================================================

    def __init__(self):
        pass

    def open(self):
        errText = None
        self.m_objPCANBasic = PCANBasic()
        self.m_can_handle = PCAN_USBBUS1
        result = self.m_objPCANBasic.Initialize(self.m_can_handle, PCAN_BAUD_1M)
        if result != PCAN_ERROR_OK:
            self.m_can_handle = PCAN_PCIBUS1  # some computers may have a PCI-card built in instead of a PCAN-USB-dongle
            result = self.m_objPCANBasic.Initialize(self.m_can_handle, PCAN_BAUD_1M)
            if result != PCAN_ERROR_OK:
                errText = "PCANBasic.Initialize Error"
        return errText

    def close(self):
        self.m_objPCANBasic.Uninitialize(self.m_can_handle)

    def send(self, msg):
        errText = None
        result = self.m_objPCANBasic.Write(self.m_can_handle, msg)
        if result != PCAN_ERROR_OK:
            # if self.modules[id&0xff].getThrowError():
            errText = "PCANBasic.Write Error"
        return errText

    def read_in_loop(self):  # read is called in loop
        msg = None
        errText = None
        readResult = [PCAN_ERROR_OK]
        if (readResult[0] & PCAN_ERROR_QRCVEMPTY) != PCAN_ERROR_QRCVEMPTY:
            readResult = self.m_objPCANBasic.Read(self.m_can_handle)
            if readResult[0] == PCAN_ERROR_OK:
                msg = readResult[1]  # [1]=message [2]=timestamp
        else:
            time.sleep(0.01)
        return msg, errText


# =============================================================================
class CommInterfaceSocket:
    # =============================================================================

    def __init__(self, useIrregularEventLog=False, useIrregularEventGUI=False):
        self.useIrregularEventLog = useIrregularEventLog
        self.useIrregularEventGUI = useIrregularEventGUI

    def open(self):
        errText = None
        self.mySocket = socket.socket()  # Create a socket object
        self.connected = False
        host = socket.gethostname()  # Get local machine name
        port = tcpIpPort  # Reserve a port for your service.

        try:
            self.mySocket.connect((host, port))
            self.connected = True
        except:
            print("No server found. Starting Server ...")
            ps = os.path.abspath(os.path.dirname(sys.argv[0]))
            i = ps.find(os.sep + "MCS_PYTHON_SIMPLE")
            ps = ps[0:i] + os.sep + "MCS_PYTHON_SIMPLE"
            if os.name == "nt":
                p1 = ps + os.sep + "App" + os.sep + "pythonw.exe"
            else:
                raise ValueError("operating system not yet supported")

            p2 = ps + os.sep + "TestScripts" + os.sep + "_common" + os.sep + "MCS_Server.py"

            if not os.path.isfile(p1):
                errText = "Start MCS server error: file " + p1 + " not found"
            elif not os.path.isfile(p2):
                errText = "Start MCS server error: file " + p2 + " not found"

            else:
                p3 = "False"
                p4 = "True" if self.useIrregularEventLog else "False"
                p5 = "True" if self.useIrregularEventGUI else "False"

                DETACHED_PROCESS = 0x00000008
                subprocess.Popen([p1, p2, p3, p4, p5], shell=False, stdin=None, stdout=None, stderr=None,
                                 close_fds=True, creationflags=DETACHED_PROCESS)
                for i in range(5):
                    try:
                        self.mySocket.connect((host, port))
                        self.connected = True
                        break
                    except:
                        print("waiting for connection to server...")
                        time.sleep(0.5)

                if not self.connected:
                    errText = "Could not start MCS server..."

        return errText

    def close(self):
        if self.connected:
            self.mySocket.shutdown(socket.SHUT_RDWR)
        self.mySocket.close()

    def send(self, msg):
        data = packMsg(msg)
        try:
            self.mySocket.sendall(data)
        except:
            errText = "Connection to MCS server lost..."
        else:
            errText = None
        return errText

    def read_in_loop(self):  # read is called in loop
        try:
            answ = self.mySocket.recv(14)
        except:
            msg = None
            errText = "Connection to MCS server lost..."
        else:
            if len(answ) == 14:
                errText = None
                msg = unpackMsg(answ)
                # print "read",
                # printMsg(msg)
            else:
                msg = None
                errText = "Socket Data Length <> 14 !!"
        return msg, errText


# =============================================================================
class Mcs:
    # =============================================================================
    instanceCounter = 0

    def __init__(self, useServer=True,
                 guiUpdate=None,
                 useIrregularEventLog=False,
                 useIrregularEventGUI=False):

        super(Mcs, self).__init__()

        self.useServer = useServer
        self.guiUpdate = guiUpdate  # function that will be called during waitReady

        self.useIrregularEventLog = useIrregularEventLog
        self.useIrregularEventGUI = useIrregularEventGUI if self.useIrregularEventLog else False

        self.lock = threading.Lock()
        self.errorLock = threading.Lock()

        self.errorCode = 0
        self.errorCanId = 0
        self.errorText = ""
        self.noResume = False  # allows to block the resume button on error window even if error window is
        # initialized with resume=True
        # to be used in severe error cases where no resume possible

        self.newErrorReportDelay = 4  # used by newErrorReporter. decremented every 500ms: 4->3 3->2 2->1 (3x500ms)
        # if 1 : getError() and setError() and set to 0
        # if 0 : do nothing
        self.raiseError = True
        self.stoppedByUser = False
        self.closed = True

    def wrapper_scan(self,id_list=[]):
        countOfModules = 0
        existingModules = []
        isConnected = False
        for item in id_list:
            if not isConnected:
                isConnected = self.isConnected(item)
                countOfModules = (countOfModules + 1) if isConnected else countOfModules
                existingModules = (existingModules + [hex(item)]) if isConnected else existingModules
            else:
                break
        return (countOfModules, existingModules)

    def start(self):

        if self.__class__.instanceCounter != 0:
            raise Exception(
                "Only one running instance of class mcs allowed!! Use function close() before calling start().")
        else:
            self.__class__.instanceCounter += 1

        print("mcs started")

        self.modules = []
        for canId in range(0, 256):
            self.modules.append(CanModule(self, canId))

        if self.useServer:  # use MCS Server
            self.commInterface = CommInterfaceSocket(self.useIrregularEventLog, self.useIrregularEventGUI)
        else:  # use direct connection to PCAN Basic
            self.commInterface = CommInterfaceCAN()

        errText = self.commInterface.open()
        if errText:
            self.setError(0, 0, errorText=errText, suppressRaise=True, noResume=True)

        if errText is None:
            self.Reader = Reader(self.modules, self)
        else:
            self.Reader = None
        self.closed = False

    def close(self):
        print("mcs closed")
        self.__class__.instanceCounter = 0
        self.closed = True
        if self.Reader:
            self.Reader.close()
        self.commInterface.close()

    def sendMsg(self, cmdId, data, nonLocking=False):  # len defined by len of data
        return self.sendMsgLen(cmdId, len(data), data, nonLocking)

    def sendMsgLen(self, canId, msgLen, data, nonLocking=False):
        if self.stoppedByUser:
            raise McsStoppedByUser
        if not nonLocking:
            self.lock.acquire()
        CANMsg = TPCANMsg()
        CANMsg.ID = canId
        CANMsg.LEN = msgLen
        CANMsg.MSGTYPE = PCAN_MESSAGE_STANDARD
        for i in range(CANMsg.LEN):
            CANMsg.DATA[i] = data[i]

        errText = self.commInterface.send(CANMsg)
        if errText:
            self.setError(0, canId, errText)

        return CANMsg  # for debug printing

    def rcvMsg(self, canId, timeout_ms=300):
        if not self.lock.locked():
            return None
        canId &= 0xff
        poll_s = 0.010  # 10ms
        ok = False
        for x in range(int(timeout_ms / poll_s / 1000)):
            if self.modules[canId].getMsgAvailable() > 0:
                ok = True
                break
            time.sleep(poll_s)
        if self.lock.locked():
            self.lock.release()
        if ok:
            return self.modules[canId].getMsg()  # return None if timeout
        else:
            self.setError(0, canId, "ACK timeout error")
            return None

    def compareMsg(self, msg, canId=0xfff, msgLen=0xfff,
                   data0=0xfff, data1=0xfff,
                   data2=0xfff, data3=0xfff,
                   data4=0xfff, data5=0xfff,
                   data6=0xfff, data7=0xfff,
                   throwError=True):
        if msg is None:
            return False

        if msg.DATA[0] == 0x00:  # Info0

            if msg.DATA[1] & STATUS_Error:
                err = self.getError(msg.ID)
                self.setError(err, msg.ID, "module error")
                return False

            if msg.DATA[2] == 0xff:  # Info0 NACK
                cerr = self.getError(msg.ID)
                self.setError(cerr, msg.ID, "communication error")
                return False

        result = True
        if (canId != 0xfff) and (id != msg.ID):
            result = False
        if (msgLen != 0xfff) and (msgLen != msg.LEN):
            result = False
        if (data0 != 0xfff) and (data0 != msg.DATA[0]):
            result = False
        if (data1 != 0xfff) and (data1 != msg.DATA[1]):
            result = False
        if (data2 != 0xfff) and (data2 != msg.DATA[2]):
            result = False
        if (data3 != 0xfff) and (data3 != msg.DATA[3]):
            result = False
        if (data4 != 0xfff) and (data4 != msg.DATA[4]):
            result = False
        if (data5 != 0xfff) and (data5 != msg.DATA[5]):
            result = False
        if (data6 != 0xfff) and (data6 != msg.DATA[6]):
            result = False
        if (data7 != 0xfff) and (data7 != msg.DATA[7]):
            result = False
        if not result and throwError:
            self.setError(0, msg.ID, "unexpected CAN Message")
        return result

    def unsignedToSigned(self, value, valueBytes):
        bits = valueBytes * 8
        if (value & (1 << (bits - 1))) != 0:
            value = value - (1 << bits)
        return value

    def scanForModules(self, startCanId=0x400, lastCanId=0x4ff, timeout_ms=300):
        if self.useServer:
            raise AssertionError("scanForModules not possible with useServer==True")
        startCanIdx = startCanId & 0xff
        lastCanIdx = lastCanId & 0xff
        for idx in range(startCanIdx, lastCanIdx + 1):
            while self.modules[idx].getMsgAvailable() > 0:  # empty buffer
                self.modules[idx].getMsg()
            self.sendMsg(idx + 0x400, [0x1b, 0x03], nonLocking=True)
        time.sleep(timeout_ms / 1000.0)
        existingModules = []
        countOfModules = []
        for idx in range(startCanIdx, lastCanIdx + 1):
            count = self.modules[idx].getMsgAvailable()  # >1 if more than one module with this CAN address
            if count > 0:
                existingModules.append(idx + 0x400)
                countOfModules.append(count)
                for i in range(count):
                    self.modules[idx].getMsg()
        return existingModules, countOfModules

    def waitReady(self, canId, waitReadyTime=10):
        for i in range(int(waitReadyTime / 0.1)):
            if self.guiUpdate:
                self.guiUpdate()
            time.sleep(0.1)
            if self.stoppedByUser:
                raise McsStoppedByUser
            # print ".",
            if self.isIdle(canId):
                break
        if self.isBusy(canId):
            self.setError(0, canId, "waitReady timeout")
        if self.hasError(canId):
            err = self.getError(canId)
            self.setError(err, canId, "module error during waitReady")

    def init(self, canId, cmdMode=0, waitReadyTime=10):
        self.sendMsg(canId, [0x22, cmdMode])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x22)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def reset(self, canId, cmdMode=0xff, waitReadyTime=10):
        self.sendMsg(canId, [0x1c, cmdMode])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x1c)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def operate(self, canId, cmdMode, waitReadyTime=0):  # !!! default different from other commands !!!
        self.sendMsg(canId, [0xef, cmdMode])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xef)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def setTargetValue(self, canId, value):
        self.sendMsg(canId, [0xe2, value & 0xff, (value >> 8) & 0xff])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xe2)

    def setTargetValueBDC(self, canId, value):
        """
        deprecated: only used in Prodigy TEC Board Rev5 Firmware
        new designs should use 0xE2 telegram
        """
        self.sendMsg(canId, [0xe5, value & 0xff, (value >> 8) & 0xff])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xe5)

    def rotate(self, canId, cmdMode, direction, speed):
        data = [0x25, cmdMode, direction & 0xFF, speed & 0xFF, (speed >> 8) & 0xFF]
        self.sendMsg(canId, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x25)

    def move(self, canId, cmdMode, position, speed, waitReadyTime=10):
        data = [0x23, cmdMode, position & 0xFF, (position >> 8) & 0xFF, (position >> 16) & 0xFF,
                (position >> 24) & 0xFF, speed & 0xFF, (speed >> 8) & 0xFF]
        self.sendMsg(canId, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x23)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def moveDiscrete(self, canId, cmdMode, positionID, direction='CCW', waitReadyTime=10):
        data = [0x24, cmdMode]
        if direction == 'CCW':
            positionID = positionID | 0x00
        elif direction == "CW":
            positionID = positionID | 0x80
        elif direction == "SHORTEST":
            positionID = positionID | 0x40
        data.append(positionID & 0xFF)
        self.sendMsg(canId, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x24)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def getMove(self, canId):
        self.sendMsg(canId, [0x26, 0x00])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0, 0
        self.compareMsg(answer, data0=0x27)
        shift = 0
        position = 0
        for i in range(2, 6):
            position = position | (answer.DATA[i] << shift)
            shift = shift + 8
        position = self.unsignedToSigned(position, 4)
        shift = 0
        speed = 0
        for i in range(6, 8):
            speed = speed | (answer.DATA[i] << shift)
            shift = shift + 8
        speed = self.unsignedToSigned(speed, 2)
        return position, speed

    def setRamping(self, canId, accel, decel):
        data = [0x28, accel & 0xFF, (accel >> 8) & 0xFF, decel & 0xFF, (decel >> 8) & 0xFF]
        self.sendMsg(canId, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x28)

    def getRamping(self, canId):
        self.sendMsg(canId, [0x29])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0, 0
        self.compareMsg(answer, data0=0x2A)
        shift = 0
        accel = 0
        for i in range(1, 3):
            accel = accel | (answer.DATA[i] << shift)
            shift = shift + 8
        shift = 0
        decel = 0
        for i in range(3, 5):
            decel = decel | (answer.DATA[i] << shift)
            shift = shift + 8
        return accel, decel

    def setDiscretePosition(self, canId, positionID, position):
        data = [0x2B, positionID & 0xFF, position & 0xFF, (position >> 8) & 0xFF]
        self.sendMsg(canId, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x2B)

    def getDiscretePosition(self, canId, positionID):
        self.sendMsg(canId, [0x2C])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x2D, data1=positionID)
        shift = 0
        position = 0
        for i in range(2, 6):
            position = position | (answer.DATA[i] << shift)
            shift = shift + 8
        return position

    def stop(self, canId, cmdMode=0):
        self.sendMsg(canId, [0x2f, cmdMode])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x2f)

    def getPort(self, canId, port, signed=False):
        self.sendMsg(canId, [0x41, port])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x42, data2=port)
        shift = 0
        result = 0
        for i in range(4, answer.LEN):
            result = result | (answer.DATA[i] << shift)
            shift = shift + 8
        if signed:
            result = self.unsignedToSigned(result, valueBytes=answer.LEN - 4)
        return result

    def setPort(self, canId, length, port, value, pulseTime=0):
        data = [0x40, 0x00, port, pulseTime, value & 0xFF, (value >> 8) & 0xFF, (value >> 16) & 0xFF,
                (value >> 24) & 0xFF]
        self.sendMsgLen(canId, length + 4, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x40)

    def setPortMode(self, canId, port, mode, dataValidTime=0, portIdleTime=0):
        data = [0x43, port, mode, dataValidTime & 0xFF, (dataValidTime >> 8) & 0xFF, portIdleTime & 0xFF,
                (portIdleTime >> 8) & 0xFF]
        self.sendMsgLen(canId, 7, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x43)

    def getPortParameter(self, canId, port, parameter, signed=False):
        self.sendMsg(canId, [0x4a, 0, port, parameter])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x4b, data2=port, data3=parameter)
        shift = 0
        result = 0
        for i in range(4, answer.LEN):
            result = result | (answer.DATA[i] << shift)
            shift = shift + 8
        if signed:
            result = self.unsignedToSigned(result, valueBytes=answer.LEN - 4)
        return result

    def setPortParameter(self, canId, length, port, parameter, value):
        data = [0x49, 0, port, parameter, value & 0xFF, (value >> 8) & 0xFF]
        self.sendMsgLen(canId, length + 4, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x49)

    def portZeroSet(self, canId, port, waitReadyTime=5):
        self.sendMsg(canId, [0x4c, 0, port])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x4c)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def getParameter(self, canId, parameter, signed=False):
        self.sendMsg(canId, [0xdb, parameter])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0xdc, data1=parameter)
        shift = 0
        result = 0
        for i in range(2, answer.LEN):
            result = result | (answer.DATA[i] << shift)
            shift = shift + 8
        if signed:
            result = self.unsignedToSigned(result, valueBytes=answer.LEN - 2)
        return result

    def setParameter(self, canId, length, parameter, value):
        value = int(value)
        data = [0xDE, parameter, value & 0xFF, (value >> 8) & 0xFF, (value >> 16) & 0xFF, (value >> 24) & 0xFF, 0, 0]
        self.sendMsgLen(canId, length + 2, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xde)

    def getMem(self, canId, length, address, signed=False):
        d = [0xFB, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF, length & 0xFF]
        self.sendMsgLen(canId, 5, d)
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0xFC)
        shift = 0
        result = 0
        for i in range(1, answer.LEN):
            result |= answer.DATA[i] << shift
            shift += 8
        if signed:
            result = self.unsignedToSigned(result, valueBytes=answer.LEN - 1)
        return result

    def eraseMem(self, canId, address, waitReadyTime=15):
        data = [0xFD, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF]
        self.sendMsgLen(canId, 4, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xFD)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def setMem(self, canId, length, address, data):
        d = [0xFE, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF, data & 0xFF, (data >> 8) & 0xFF,
             (data >> 16) & 0xFF, (data >> 24) & 0xFF]
        self.sendMsgLen(canId, length + 4, d)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xfe)

    def setMem2(self, canId, length, address, data0, data1, data2, data3):
        d = [0xFE, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF, data0, data1, data2, data3]
        self.sendMsgLen(canId, length + 4, d)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xfe)

    def setMemArray(self, canId, length, address, data):
        d = [0xFE, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF]
        for i in range(0, length):
            d.append(ord(data[i]))
        self.sendMsgLen(canId, length + 4, d)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xFE)

    def getMemArray(self, canId, length, address):
        d = [0xFB, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF, length & 0xFF]
        self.sendMsgLen(canId, 5, d)
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0xFC)
        data = []
        for i in range(1, length + 1):
            data.append(answer.DATA[i])
        return data

    def getMemString(self, canId, length, address):
        d = [0xFB, address & 0xFF, (address >> 8) & 0xFF, (address >> 16) & 0xFF, length & 0xFF]
        self.sendMsgLen(canId, 5, d)
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0xFC)
        data = ""
        for i in range(1, length + 1):
            data += chr(answer.DATA[i])
        return data

    def setAuxData(self, canId, length, data):
        d = [0x55]
        for i in range(0, length):
            d.append(data[i])
        self.sendMsgLen(canId, length + 1, d)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x55)

    def getAuxData(self, canId, length=0x08):
        d = []
        self.sendMsg(canId, [0x53])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x54)
        for i in range(1, length + 1):
            d.append(answer.DATA[i])
        return d

    def getError(self, canId):  # info1
        self.sendMsg(0x400 | canId, [0x1b, 0x01])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x01)
        return answer.DATA[2] | (answer.DATA[3] << 8)

    def getVersion(self, canId, versionType=0):  # info3
        self.sendMsg(canId, [0x1b, 0x03])
        answer = self.rcvMsg(canId)
        if answer is None:
            return "---"
        self.compareMsg(answer, data0=0x03)
        if versionType == 0:  # e.g. 1.2.0r
            return "%d.%d.%d. %c" % (answer.DATA[4], answer.DATA[5], answer.DATA[6], answer.DATA[7])
        elif versionType == 1:  # medical version format
            shift = 0
            result = 0
            for i in range(4, len(answer.DATA)):
                result = result | (answer.DATA[i] << shift)
                shift = shift + 8
            if result > 9999999:
                result = result % 10000000
                return "E_%6d_%d" % (result / 10, result % 10)
            else:
                return "I_%6d_%d" % (result / 10, result % 10)
        elif versionType == 2:  # for >< comparison
            return "%02d.%02d.%02d %c" % (answer.DATA[4], answer.DATA[5], answer.DATA[6], answer.DATA[7])
        else:
            return ""

    def getHardwareVersion(self, canId):  # info5
        self.sendMsg(canId, [0x1b, 0x05])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x05)
        return answer.DATA[3]

    def getCommunicationError(self, canId):  # info6
        self.sendMsg(canId, [0x1b, 0x06])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=0x06)
        return answer.DATA[2] | (answer.DATA[3] << 8)

    def getBootInfo(self, canId, infoId):
        self.sendMsg(canId, [0x1b, infoId])
        answer = self.rcvMsg(canId)
        if answer is None:
            return 0
        self.compareMsg(answer, data0=infoId)
        info = [answer.DATA[1], answer.DATA[2], answer.DATA[3], answer.DATA[4], answer.DATA[5], answer.DATA[6],
                answer.DATA[7]]
        return info

    def setBootMode(self, canId, mode, crc, waitReadyTime=15):
        data = [0xFA, mode, crc & 0xFF, (crc >> 8) & 0xFF]
        self.sendMsg(canId, data)
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xFA)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def goBoot(self, canId, waitReadyTime=2):
        self.sendMsg(canId, [0xf8])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xf8)
        # Just 2 seconds pause.
        if waitReadyTime > 0:
            for i in range(int(waitReadyTime / 0.1)):
                time.sleep(0.1)

    def initBoot(self, canId, cmdMode=0, waitReadyTime=10):
        self.sendMsg(canId, [0x1D, cmdMode])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0x1D)
        if waitReadyTime > 0:
            self.waitReady(canId, waitReadyTime)

    def goMain(self, canId, waitReadyTime=2):
        self.sendMsg(canId, [0xf9])
        answer = self.rcvMsg(canId)
        self.compareMsg(answer, msgLen=3, data0=0, data2=0xf9)
        # Just 2 seconds pause.
        if waitReadyTime > 0:
            for i in range(int(waitReadyTime / 0.1)):
                time.sleep(0.1)

    def getStatus(self, canId):
        return self.modules[canId & 0xff].getStatus()

    def isBusy(self, canId):
        return bool(self.getStatus(canId) & STATUS_Active)

    def isPrepared(self, canId):
        return bool(self.getStatus(canId) & STATUS_Prepared)

    def isNotInitialized(self, canId):
        return bool(self.getStatus(canId) & STATUS_NotInit)

    def isInitialized(self, canId):
        return not self.isNotInitialized(canId)

    def isIdle(self, canId):
        return not self.isBusy(canId)

    def hasError(self, canId):
        return bool(self.getStatus(canId) & STATUS_Error)

    def hasWarning(self, canId):
        return bool(self.getStatus(canId) & STATUS_Warning)

    def hasData(self, canId):
        return bool(self.getStatus(canId) & STATUS_Data)

    def hasDetected(self, canId):
        return bool(self.getStatus(canId) & STATUS_Detected)

    def setThrowError(self, canId, setting=True):
        self.modules[canId & 0xff].setThrowError(setting)

    def setRaiseError(self, setting=True):
        self.raiseError = setting

    def setStoppedByUser(self, setting=True):
        self.stoppedByUser = setting

    def setThrowBufferOverflow(self, canId, setting=True):
        self.modules[canId & 0xff].setThrowBufferOverflow(setting)

    def isConnected(self, canId, timeout=300, hotplug=False):
        if not hotplug:
            if self.modules[canId & 0xff].connected is not None:
                return self.modules[canId & 0xff].connected

        self.modules[canId & 0xff].setThrowError(setting=False)
        self.sendMsg(canId, [0x1b, 0x03])  # try info3 to detect if module is connected
        answer = self.rcvMsg(canId, timeout)
        self.modules[canId & 0xff].setThrowError(setting=True)
        self.modules[canId & 0xff].connected = False if answer is None else True

        return self.modules[canId & 0xff].connected

    def dumpMsgAvailable(self):  # dump all IDs with messages available
        print("--- dumpMsgAvailable ---")
        for canId in range(len(self.modules)):
            a = self.modules[canId].getMsgAvailable()
            if a:
                print("CanId: 0x%2x Messages: %d" % (canId, a))
        print("------------------------")

    # ---------- MCS Error handling --------------------------------------------

    def setError(self, errorCode, errorCanId, errorText, suppressRaise=False, noResume=False):
        # ~ logging.critical('MCS HW error: module ' + hex(errorCanId) + ' reported ' + errorText +
        # ~ ', error code ' + hex(errorCode))

        self.modules[errorCanId & 0xff].newErrorTimer = 0  # nothing to do for newErrorReporter

        if self.lock.locked():
            self.lock.release()

        if not self.modules[errorCanId & 0xff].throwError:
            print("ignored (throwError Off):"),
            print("setError 0x{0:x} canID 0x{1:x} {2:s}".format(errorCode, errorCanId, errorText))
            return

        if self.errorLock.locked():
            print("ignored (already in error state):"),
            if (not suppressRaise) and self.raiseError:
                print("setError 0x{0:x} canID 0x{1:x} {2:s} - existing error raised again".format(errorCode, errorCanId,
                                                                                                  errorText))
                raise McsError
            else:
                print("setError 0x{0:x} canID 0x{1:x} {2:s}".format(errorCode, errorCanId, errorText))

        else:
            print("setError 0x{0:x} canID 0x{1:x} {2:s}".format(errorCode, errorCanId, errorText))
            self.errorTrace = traceback.format_stack()
            self.errorLock.acquire()
            self.errorCode = errorCode
            self.errorCanId = errorCanId
            self.errorText = errorText
            self.noResume = noResume
            # TODO emit Error here
            if (not suppressRaise) and self.raiseError:
                raise McsError

    def resetError(self):
        self.errorTrace = ""
        self.errorCode = 0
        self.errorCanId = 0
        self.errorText = ""
        self.noResume = False
        if self.errorLock.locked():
            self.errorLock.release()

    def getErrorMessage(self):
        if not self.errorLock.locked():
            return "No Error"
        if self.errorCode == 0:
            errorStr = "Error "
        else:
            errorStr = "Error 0x%x (%d) " % (self.errorCode, self.errorCode)

        if self.errorCanId == 0:
            errorStr += ""
        else:
            self.errorCanId = self.errorCanId | 0x400
            errorStr += "on CAN ID 0x%x (%d) = %s " % (self.errorCanId, self.errorCanId,
                                                       self.getModuleName(self.errorCanId))

        errorStr += "\n"

        if len(self.errorText) > 0:
            errorStr += self.errorText
            errorStr += "\n"

        errorStr += self.getErrorText(self.errorCode, self.errorCanId)
        errorStr += "\n\n"

        for line in self.errorTrace:
            if "TestScripts" in line:  # include only lines containing "TestScripts"-folder
                errorStr += line
                if "mcs.py" in line or "mcs2.py" in line:  # last line = first line containing "mcs.py"
                    break
        return errorStr

    def getErrorMessageConsole(self):
        errorStr = "\n=================== Error ===================\n"
        errorStr += self.getErrorMessage()
        errorStr += "=============================================\n"
        return errorStr

    def getErrorText(self, searchErrorCode, searchCanID):  # from database
        csvfile = open(os.path.dirname(os.path.abspath(__file__)) + os.sep + 'MCS_ErrorCodes.csv', 'rb')
        with io.TextIOWrapper(csvfile, newline='\n') as text_file:
            reader = csv.reader(text_file, delimiter=';')
            theText = "<no error text>"
            for row in reader:
                if ("#" in row[0]) or (row[0].strip() == ""):  # skip comment or blank lines
                    continue
                if int(row[0], 0) == searchErrorCode:
                    if row[1] == "":
                        theText = row[2]
                    elif int(row[1], 0) == searchCanID:
                        theText = row[2]
                        break
            csvfile.close()
            return theText

    def getModuleName(self, searchCanID):  # from database

        csvfile = open(os.path.dirname(os.path.abspath(__file__)) + os.sep + 'MCS_ModuleNames.csv', 'rb')
        # row[0]=CanID
        with io.TextIOWrapper(csvfile, newline='\n') as text_file:
            # row[1]=Name
            reader = csv.reader(text_file, delimiter=';')
            theName = "<no name>"
            for row in reader:
                if ("#" in row[0]) or (row[0].strip() == ""):  # skip comment or blank lines
                    continue
                if int(row[0], 0) == searchCanID:
                    theName = row[1]
                    break
            csvfile.close()
            return theName

    def getIELogger(self):
        """
        returns the logger of irregular event if mcs.useIrregularEventLog is True
        """
        if self.useIrregularEventLog:
            return self.Reader.irregularEvent.logger
        else:
            return None
