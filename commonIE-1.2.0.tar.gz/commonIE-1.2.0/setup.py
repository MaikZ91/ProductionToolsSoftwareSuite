import setuptools

setuptools.setup(
    name='commonIE',
    version='1.2.0',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='lukasm',
    author_email='lukasm@miltenyi.com',
    description='Added DbCommunicator to the CommonIE Framework'
)