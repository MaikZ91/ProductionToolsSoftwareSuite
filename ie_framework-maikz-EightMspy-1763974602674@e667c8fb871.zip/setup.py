import setuptools

setuptools.setup(
    name='ie_Framework',
    version='1.2.5',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='lukasm',
    author_email='lukasm@miltenyi.com',
    description='Standard IE Framework for easier Updates and Setup of future projects',
    changes="Added function to processOverview that allows to add custom graphs."
)